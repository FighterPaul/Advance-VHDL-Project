/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/KMITL/Year_3/term2/Advanced Digital Design Using HDL/Projects/CLOCK/InterfaceLCDV2.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1258338084_503743352(char *, char *, unsigned int , unsigned int );
unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );


static void work_a_2770794201_1446275585_p_0(char *t0)
{
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    int t8;
    int t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    int t13;
    int t14;
    char *t15;
    unsigned int t16;
    int t17;
    int t18;
    int t19;
    int t20;
    unsigned int t21;
    unsigned int t22;
    int t23;
    int t24;
    int t25;
    int t26;
    int t27;
    int t28;
    int t29;
    int t30;
    int t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    char *t35;
    char *t36;

LAB0:    xsi_set_current_line(38, ng0);
    t1 = (t0 + 1312U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 1312U);
    t2 = ieee_p_2592010699_sub_1258338084_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB5;

LAB6:    t1 = (t0 + 992U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB7;

LAB8:
LAB3:    t1 = (t0 + 3952);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(39, ng0);
    t3 = (t0 + 4032);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((int *)t7) = 0;
    xsi_driver_first_trans_fast(t3);
    xsi_set_current_line(40, ng0);
    t1 = (t0 + 4096);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((int *)t6) = 1;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(41, ng0);
    t1 = (t0 + 4160);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((int *)t6) = 1;
    xsi_driver_first_trans_fast(t1);
    goto LAB3;

LAB5:    xsi_set_current_line(43, ng0);
    t3 = (t0 + 4032);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((int *)t7) = 0;
    xsi_driver_first_trans_fast(t3);
    xsi_set_current_line(44, ng0);
    t1 = (t0 + 4096);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((int *)t6) = 1;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(45, ng0);
    t1 = (t0 + 4160);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((int *)t6) = 1;
    xsi_driver_first_trans_fast(t1);
    goto LAB3;

LAB7:    xsi_set_current_line(48, ng0);
    t3 = (t0 + 2152U);
    t4 = *((char **)t3);
    t8 = *((int *)t4);
    t9 = (t8 + 1);
    t3 = (t0 + 4032);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t10 = *((char **)t7);
    *((int *)t10) = t9;
    xsi_driver_first_trans_fast(t3);
    xsi_set_current_line(50, ng0);
    t1 = (t0 + 2152U);
    t3 = *((char **)t1);
    t8 = *((int *)t3);
    t2 = (t8 <= 2000);
    if (t2 != 0)
        goto LAB9;

LAB11:    t1 = (t0 + 2152U);
    t3 = *((char **)t1);
    t8 = *((int *)t3);
    t11 = (t8 > 2000);
    if (t11 == 1)
        goto LAB14;

LAB15:    t2 = (unsigned char)0;

LAB16:    if (t2 != 0)
        goto LAB12;

LAB13:    t1 = (t0 + 2152U);
    t3 = *((char **)t1);
    t8 = *((int *)t3);
    t11 = (t8 > 8000);
    if (t11 == 1)
        goto LAB19;

LAB20:    t2 = (unsigned char)0;

LAB21:    if (t2 != 0)
        goto LAB17;

LAB18:    t1 = (t0 + 2152U);
    t3 = *((char **)t1);
    t8 = *((int *)t3);
    t2 = (t8 == 10000);
    if (t2 != 0)
        goto LAB22;

LAB23:
LAB10:    xsi_set_current_line(75, ng0);
    t1 = (t0 + 2472U);
    t3 = *((char **)t1);
    t8 = *((int *)t3);
    if (t8 == 1)
        goto LAB33;

LAB37:    if (t8 == 2)
        goto LAB34;

LAB38:    if (t8 == 3)
        goto LAB35;

LAB39:
LAB36:    xsi_set_current_line(100, ng0);
    t1 = (t0 + 4288);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(101, ng0);
    t1 = (t0 + 4352);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(102, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 2312U);
    t4 = *((char **)t1);
    t8 = *((int *)t4);
    t9 = (t8 * 8);
    t13 = (136 - t9);
    t14 = (t13 - 1);
    t16 = (127 - t14);
    t1 = (t0 + 2312U);
    t5 = *((char **)t1);
    t17 = *((int *)t5);
    t18 = (8 * t17);
    t19 = (136 - t18);
    t20 = (t19 - 8);
    xsi_vhdl_check_range_of_slice(127, 0, -1, t14, t20, -1);
    t21 = (t16 * 1U);
    t22 = (0 + t21);
    t1 = (t3 + t22);
    t6 = (t0 + 2312U);
    t7 = *((char **)t6);
    t23 = *((int *)t7);
    t24 = (t23 * 8);
    t25 = (136 - t24);
    t26 = (t25 - 1);
    t6 = (t0 + 2312U);
    t10 = *((char **)t6);
    t27 = *((int *)t10);
    t28 = (8 * t27);
    t29 = (136 - t28);
    t30 = (t29 - 8);
    t31 = (t30 - t26);
    t32 = (t31 * -1);
    t32 = (t32 + 1);
    t33 = (1U * t32);
    t2 = (8U != t33);
    if (t2 == 1)
        goto LAB46;

LAB47:    t6 = (t0 + 4416);
    t15 = (t6 + 56U);
    t34 = *((char **)t15);
    t35 = (t34 + 56U);
    t36 = *((char **)t35);
    memcpy(t36, t1, 8U);
    xsi_driver_first_trans_fast_port(t6);

LAB32:    goto LAB3;

LAB9:    xsi_set_current_line(51, ng0);
    t1 = (t0 + 4224);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB10;

LAB12:    xsi_set_current_line(54, ng0);
    t1 = (t0 + 4224);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t10 = *((char **)t7);
    *((unsigned char *)t10) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB10;

LAB14:    t1 = (t0 + 2152U);
    t4 = *((char **)t1);
    t9 = *((int *)t4);
    t12 = (t9 <= 8000);
    t2 = t12;
    goto LAB16;

LAB17:    xsi_set_current_line(57, ng0);
    t1 = (t0 + 4224);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t10 = *((char **)t7);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB10;

LAB19:    t1 = (t0 + 2152U);
    t4 = *((char **)t1);
    t9 = *((int *)t4);
    t12 = (t9 < 10000);
    t2 = t12;
    goto LAB21;

LAB22:    xsi_set_current_line(59, ng0);
    t1 = (t0 + 4224);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(60, ng0);
    t1 = (t0 + 4032);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((int *)t6) = 0;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(61, ng0);
    t1 = (t0 + 2472U);
    t3 = *((char **)t1);
    t8 = *((int *)t3);
    t9 = (t8 + 1);
    t1 = (t0 + 4096);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((int *)t7) = t9;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(63, ng0);
    t1 = (t0 + 2472U);
    t3 = *((char **)t1);
    t8 = *((int *)t3);
    t11 = (t8 >= 4);
    if (t11 == 1)
        goto LAB27;

LAB28:    t2 = (unsigned char)0;

LAB29:    if (t2 != 0)
        goto LAB24;

LAB26:    t1 = (t0 + 2472U);
    t3 = *((char **)t1);
    t8 = *((int *)t3);
    t2 = (t8 == 19);
    if (t2 != 0)
        goto LAB30;

LAB31:
LAB25:    goto LAB10;

LAB24:    xsi_set_current_line(64, ng0);
    t1 = (t0 + 2312U);
    t5 = *((char **)t1);
    t13 = *((int *)t5);
    t14 = (t13 + 1);
    t1 = (t0 + 4160);
    t6 = (t1 + 56U);
    t7 = *((char **)t6);
    t10 = (t7 + 56U);
    t15 = *((char **)t10);
    *((int *)t15) = t14;
    xsi_driver_first_trans_fast(t1);
    goto LAB25;

LAB27:    t1 = (t0 + 2472U);
    t4 = *((char **)t1);
    t9 = *((int *)t4);
    t12 = (t9 != 19);
    t2 = t12;
    goto LAB29;

LAB30:    xsi_set_current_line(67, ng0);
    t1 = (t0 + 4160);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((int *)t7) = 1;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(68, ng0);
    t1 = (t0 + 4096);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((int *)t6) = 3;
    xsi_driver_first_trans_fast(t1);
    goto LAB25;

LAB33:    xsi_set_current_line(77, ng0);
    t1 = (t0 + 4288);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(78, ng0);
    t1 = (t0 + 4352);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(79, ng0);
    t1 = (t0 + 7560);
    t4 = (t0 + 4416);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t10 = *((char **)t7);
    memcpy(t10, t1, 8U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB32;

LAB34:    xsi_set_current_line(82, ng0);
    t1 = (t0 + 4288);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(83, ng0);
    t1 = (t0 + 4352);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(84, ng0);
    t1 = (t0 + 7568);
    t4 = (t0 + 4416);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t10 = *((char **)t7);
    memcpy(t10, t1, 8U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB32;

LAB35:    xsi_set_current_line(87, ng0);
    t1 = (t0 + 1352U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t11 = (t2 == (unsigned char)2);
    if (t11 != 0)
        goto LAB41;

LAB43:    t1 = (t0 + 1352U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t11 = (t2 == (unsigned char)3);
    if (t11 != 0)
        goto LAB44;

LAB45:
LAB42:    goto LAB32;

LAB40:;
LAB41:    xsi_set_current_line(88, ng0);
    t1 = (t0 + 4288);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(89, ng0);
    t1 = (t0 + 4352);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(90, ng0);
    t1 = (t0 + 7576);
    t4 = (t0 + 4416);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t10 = *((char **)t7);
    memcpy(t10, t1, 8U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB42;

LAB44:    xsi_set_current_line(93, ng0);
    t1 = (t0 + 4288);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(94, ng0);
    t1 = (t0 + 4352);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(95, ng0);
    t1 = (t0 + 7584);
    t4 = (t0 + 4416);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t10 = *((char **)t7);
    memcpy(t10, t1, 8U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB42;

LAB46:    xsi_size_not_matching(8U, t33, 0);
    goto LAB47;

}


extern void work_a_2770794201_1446275585_init()
{
	static char *pe[] = {(void *)work_a_2770794201_1446275585_p_0};
	xsi_register_didat("work_a_2770794201_1446275585", "isim/tb_MainCircuit_isim_beh.exe.sim/work/a_2770794201_1446275585.didat");
	xsi_register_executes(pe);
}
